package package2;
import package1.Book;
/**
 * 操作系统
 */
public class OperatingSystem implements Book{
	@Override
	public void readBookName() {
		System.out.println("正在读操作系统");
	}
}
