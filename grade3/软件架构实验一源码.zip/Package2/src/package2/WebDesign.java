package package2;
import package1.Book;
/**
 * Web设计
 */
public class WebDesign implements Book{
	@Override
	public void readBookName() {
		System.out.println("正在读Web程序设计");
	}
}
