package package2;
import package1.Book;
/**
 * 计算机网络
 */
public class ComputerNetwork implements Book{
	@Override
	public void readBookName() {
		System.out.println("正在读计算机网络");
	}
}
