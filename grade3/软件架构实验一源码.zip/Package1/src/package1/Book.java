package package1;
/**
 * 书类
 */
public interface Book {
	void readBookName();
}
