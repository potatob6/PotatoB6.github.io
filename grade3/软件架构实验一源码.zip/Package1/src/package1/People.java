package package1;
/**
 * 人类
 */
public class People {
	String name;     //名字
	Book handsBook;  //手中的书
	public People(String name,Book handsBook) {
		this.name = name;
		this.handsBook = handsBook;
	}
	public void readingBook() {
		System.out.print(this.name+":");
		this.handsBook.readBookName();
	}
}
