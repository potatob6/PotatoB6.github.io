package package3;
import package1.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.*;
import java.util.Map.Entry;
public class MainClass {
	public static void main(String[] args) {
		//jar路径配置文件
		File jarPathPropertiesFile = 
				new File("/Users/ximiq/Documents/Demo1/jarPath.properties");
		//people配置文件
		File peopleToolsProperFile = 
				new File("/Users/ximiq/Documents/Demo1/PeopleTools.properties");
		
		
		//Load Properties
		//加载配置文件
		Properties jarPathProperties = new Properties();
		Properties peopleProperties = new Properties();
		try {
			InputStreamReader isr = new InputStreamReader(new FileInputStream(jarPathPropertiesFile));
			jarPathProperties.load(isr);
			isr.close();
			isr = new InputStreamReader(new FileInputStream(peopleToolsProperFile));
			peopleProperties.load(isr);
			isr.close();
			
			//Load Classes Class
			//加载Classes类
			Set<Entry<Object, Object>> pathSet = jarPathProperties.entrySet();
			Iterator<Entry<Object, Object>> pathIterator = pathSet.iterator();
			ArrayList<URL> jarPathUrls = new ArrayList<>();
			while(pathIterator.hasNext()) 
				jarPathUrls.add(new URL("file:///"+(String) pathIterator.next().getValue()));
			URL[] jarPathArray = {};
			URLClassLoader jarPathClassLoader = new URLClassLoader(jarPathUrls.toArray(jarPathArray));
			
			//Load People List
			//加载People配置
			Set<Entry<Object, Object>> peopleListSet = peopleProperties.entrySet();
			Iterator<Entry<Object, Object>> peopleIterator = peopleListSet.iterator();
			while(peopleIterator.hasNext()) {
				Entry<Object, Object> kv = peopleIterator.next();
				String name = (String) kv.getKey();
				String classPath = (String) kv.getValue();
				
				Class<?> class1 = jarPathClassLoader.loadClass(classPath);
				//Call constructor method
				//调用构造方法
				Constructor<?> constructor = class1.getDeclaredConstructor();
				Book book = (Book) constructor.newInstance();
				People people = new People(name, book);
				people.readingBook();
			}
		} catch (IOException | ClassNotFoundException | NoSuchMethodException | SecurityException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
	}
}
