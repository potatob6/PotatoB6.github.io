
public interface StudentObserver {
	void careStudent(Observable o);
}
