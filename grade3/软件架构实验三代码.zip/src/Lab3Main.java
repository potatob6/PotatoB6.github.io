
public class Lab3Main {
    public static void main(String[] args) {
    	Parent parent = new Parent();
    	Uncle uncle = new Uncle();

    	Student s = new Student("����");
    	s.addObserver(parent);
    	s.addObserver(uncle);
    	s.beAbsent(new IllAbsent());


    	s = new Student("����");
    	s.addObserver(parent);
    	s.addObserver(uncle);
    	s.beAbsent(new BusyAbsent());
    }
}
