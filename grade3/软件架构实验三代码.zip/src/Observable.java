
public interface Observable {
	void addObserver(StudentObserver so);
	void removeObserver(StudentObserver so);
	String getState();
}
