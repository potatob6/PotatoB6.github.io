public class Uncle implements StudentObserver{
    @Override
    public void careStudent(Observable o) {
        System.out.println("Uncle�Ѿ��յ�֪ͨ");
    }
}
