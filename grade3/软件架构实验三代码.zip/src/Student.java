import java.util.*;
public class Student implements Observable{
	private String name;
	private ArrayList<StudentObserver> observers = new ArrayList<>();
	private String absentState = "δ���";
	public void beAbsent(Absent a){
		a.absenceOf(this.name);
		this.absentState = "���";
		Notify();
	}
	public Student(String nm){
		this.name = nm;
	}

	@Override
	public void addObserver(StudentObserver so) {
		this.observers.add(so);
	}

	@Override
	public void removeObserver(StudentObserver so) {
		this.observers.add(so);
	}

	@Override
	public String getState() {
		return absentState;
	}

	private void Notify()
	{
		for(StudentObserver so: observers){
			so.careStudent(this);
		}
	}
}
