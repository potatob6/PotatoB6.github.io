public class Parent implements StudentObserver{
    @Override
    public void careStudent(Observable o) {
        System.out.println("Parent�Ѿ��յ����֪ͨ");
    }
}
