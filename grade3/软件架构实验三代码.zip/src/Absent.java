
public abstract class Absent {
    public void absenceOf(String nm) {
        System.out.println(nm+"��"+getReason());
        System.out.println("��ʦ��");
        this.reasonState();
        System.out.println("\t\t"+nm);
    }
    public abstract void reasonState();
    public abstract String getReason();
}
